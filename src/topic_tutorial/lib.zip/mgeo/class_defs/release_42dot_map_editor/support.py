supported_class = {
    'synced_light_set':False,
    'intersection_traffic_light_controller':False
}